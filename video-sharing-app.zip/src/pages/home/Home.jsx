import React from "react";
import PreloadedVideo from "../../components/videoComponent/PreloadedVideo";

const Home = () => {
  return (
    <>
      <PreloadedVideo />
    </>
  );
};

export default Home;
