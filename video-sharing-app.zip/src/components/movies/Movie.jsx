import React from "react";

const Movie = props => {
  console.log(props);
  return (
    <div>
      <img src={props.movieVal.downLoadURLPoster} alt="" />
    </div>
  );
};

export default Movie;
