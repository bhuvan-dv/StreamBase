import React from "react";

const ListMovies = () => {
  return <div>ListMovies</div>;
};

export default ListMovies;
