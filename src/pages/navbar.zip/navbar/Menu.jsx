import React, { useContext, useState, useRef } from "react";
import { NavLink } from "react-router-dom";
import Styles from "./navbar.module.css";
import { FaUser } from "react-icons/fa";
import { AuthContext } from "../../api/AuthContext";
const Menu = () => {
  let [toggle, setToggle] = useState(false);
  let USER = useContext(AuthContext);
  let toggleRef = useRef();
  let dropDownMenu = () => {
    setToggle(!toggle);
    // if (toggle) {
      
    // }
  };
  let AuthenticatedUser = () => {
    return (
      <>
        <li onClick={dropDownMenu}>
          <NavLink
            to={{ pathname: "/" }}
            className={Styles.navbarIconLink}
            activeClassName="active"
          >
            <span>
              <img
                src={USER.photoURL}
                alt={USER.displayName}
                className={Styles.navbarIcon}
              />
            </span>
            <span>Profile</span>
          </NavLink>
          <div
            className={Styles.dropDown}
            ref={toggleRef}
            style={toggle ? { display: "block" } : { display: "none" }}
          >
            <ul>
              <li>
                <NavLink to="/myprofile">
                  <span>
                    <FaUser /> My Profile
                  </span>
                </NavLink>
              </li>
              <li></li>
            </ul>
          </div>
        </li>
        <li>
          <NavLink to={{ pathname: "/login" }} className={Styles.navbarAnchor}>
            Logout
          </NavLink>
        </li>
      </>
    );
  };
  let AnonymousUser = () => {
    return (
      <>
        <li>
          <NavLink
            to={{ pathname: "/login" }}
            activeClassName="active"
            className={Styles.navbarAnchor}
          >
            Login
          </NavLink>
        </li>
        <li>
          <NavLink
            to={{ pathname: "/signup" }}
            activeClassName="active"
            className={Styles.navbarAnchor}
          >
            Signup
          </NavLink>
        </li>
      </>
    );
  };
  return (
    <div className={Styles.menu}>
      <ul>
        <li>
          <NavLink
            to={{ pathname: "/" }}
            activeClassName="active"
            className={Styles.navbarAnchor}
          >
            Home
          </NavLink>
        </li>
        {USER ? AuthenticatedUser() : AnonymousUser()}
      </ul>
    </div>
  );
};

export default Menu;
